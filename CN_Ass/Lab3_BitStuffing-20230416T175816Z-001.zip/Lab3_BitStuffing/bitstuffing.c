#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//gcc -c bitstuffing.c

    //Stuff 0 bit after continuous five 1's
void bitStuffing(char message[], int n){

    int arr[n];   //Stores integer array
    int brr[30];  // Stores the stuffed int array

    // printf("Initial msg inside bitstuffing: ");
    // puts(message);
    // printf("\n");

//Converting the char array to int array
    for (int i = 0; i < n; i++){
        arr[i] = (int)(message[i]-'0');
    }

    // printf("\n Checking number array \n");
    // for (int i = 0; i < n; i++)
    // printf("%d ", arr[i]);
    // printf("\n");

    int j=0, count=0;

    for (int i = 0; i < n; i++){
        
        if (count == 5){
            brr[j] == 0;
            j++;
            count=0;
        }

        if (arr[i]==1){
            brr[j] = arr[i];
            j++;
            count++;
        }else{//arr[i] == 0
            brr[j] = arr[i];
            j++;
            count = 0;
        }
    }

    // printf("After bitstuffing: ");
    // for (int i = 0; i < j; i++){
    //     printf("%d ", brr[i]);
    // }
    // printf("\n");
    
    for (int i = 0; i < j; i++){
        message[i] = (char)('0' + brr[i]);
    }

    // printf("Char array after bitstuffing: ");
    // for (int i = 0; i < j; i++){
    //     printf("%c", message[i]);
    // }
    // printf("\n");
    // printf("%d", (int)(strlen(message)));
    
}