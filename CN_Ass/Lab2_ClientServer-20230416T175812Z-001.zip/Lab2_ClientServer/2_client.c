#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> // for close
#include <sys/socket.h>
#include <netinet/in.h>

void error(char* msg){
    perror(msg);
    exit(1);
}

int main(int argc, char const *argv[])
{
    int clientsocket;
    struct sockaddr_in serveraddress;
//1
    clientsocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientsocket < 0){
        error("Error creating socket");
    }else{
        printf("Socket created successfully\n");
    }

    serveraddress.sin_family = AF_INET;
    serveraddress.sin_port = htons(9000);
    //serveraddress.sin_addr.s_addr= htons("192.168.56.1");
    serveraddress.sin_addr.s_addr = INADDR_ANY;

//2
    int connectStatus = connect(clientsocket, (struct sockaddr*) &serveraddress, sizeof(serveraddress));
    if (connectStatus == -1){
        error("Error connecting");
    }else{
        printf("Connection successful\n");
    }
    
    char server_response[255];
    int len =  sizeof(server_response);

//3
    recv(clientsocket, &server_response, len, 0);
    printf("Server: %s\n", server_response);
//4
    close(clientsocket);
    return 0;
}
