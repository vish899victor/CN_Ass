#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> // for close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

void error(char *msg){
    perror(msg);
    exit(1);
}

int main(int argc, char const *argv[])
{
    int serversocket, client_socket, bindstatus;
    char servermessage[255] = "Hello World" ;
    struct sockaddr_in serveraddress;
//1
    serversocket = socket(AF_INET, SOCK_STREAM, 0);

    serveraddress.sin_family=AF_INET;
    serveraddress.sin_port=htons(9000);
    serveraddress.sin_addr.s_addr = INADDR_ANY;
//2
    bindstatus = bind(serversocket, (const struct sockaddr *)&serveraddress, sizeof(serveraddress));
    if (bindstatus < 0)
    {
        error("Binding failed");
    }else{
        printf("Binding successful\n");
    }
//3
    listen(serversocket, 3);
    printf("Send reply to the client\n");
//4
    //clientsocket=accept(serversocket,( struct sockaddr *)&clientsocket, sizeof(clientsocket));
    client_socket = accept(serversocket, NULL, NULL);
    if (client_socket < 0)
    {
        error("Connection rejected");
    }else{
        printf("connection accepted\n");
    }
    printf("/n");
//5
    send(client_socket, servermessage, sizeof(servermessage), 0);
//6
    close(serversocket);
    return 0;
}
