#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h> // for close
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>

#define CMAX  10  //max. number of variables in economic function
#define VMAX  10  //max. number of constraints

int NC, NV, NOPTIMAL,P1,P2,XERR;
double TS[CMAX][VMAX];

void error(char* msg){
    perror(msg);
    exit(1);
}

void Simplex() {
e10: Pivot();
     Formula();
     Optimize();
     if (NOPTIMAL == 1) goto e10;
}

void Pivot() {

    double RAP,V,XMAX;
    int I,J;

    XMAX = 0.0;
    for(J=2; J<=NV+1; J++) {
	if (TS[1][J] > 0.0 && TS[1][J] > XMAX) {
        XMAX = TS[1][J];
        P2 = J;
      }
    }

    RAP = 999999.0;
    for (I=2; I<=NC+1; I++) {
      if (TS[I][P2] >= 0.0) goto e10;
      V = fabs(TS[I][1] / TS[I][P2]);
      if (V < RAP) {
        RAP = V;
        P1 = I;
      }
e10:;}
    V = TS[0][P2]; TS[0][P2] = TS[P1][0]; TS[P1][0] = V;
}


void Formula() {;
    //Labels: e60,e70,e100,e110;
    int I,J;

    for (I=1; I<=NC+1; I++) {
      if (I == P1) goto e70;
      for (J=1; J<=NV+1; J++) {
        if (J == P2) goto e60;
        TS[I][J] -= TS[P1][J] * TS[I][P2] / TS[P1][P2];
e60:;}
e70:;}
    TS[P1][P2] = 1.0 / TS[P1][P2];
    for (J=1; J<=NV+1; J++) {
      if (J == P2) goto e100;
      TS[P1][J] *= fabs(TS[P1][P2]);
e100:;}
    for (I=1; I<=NC+1; I++) {
      if (I == P1) goto e110;
      TS[I][P2] *= TS[P1][P2];
e110:;}
}   


void Optimize() {
    int I,J;
    for (I=2; I<=NC+1; I++)
      if (TS[I][1] < 0.0)  XERR = 1;
    NOPTIMAL = 0;
    if (XERR == 1)  return;
    for (J=2; J<=NV+1; J++)
      if (TS[1][J] > 0.0)  NOPTIMAL = 1;
}


void Results() {
    //Labels: e30,e70,e100;
    int I,J;
    
    if (XERR == 0) goto e30;
    printf(" NO SOLUTION.\n"); goto e100;
e30:for (I=1; I<=NV; I++)
    for (J=2; J<=NC+1; J++) {
      if (TS[J][0] != 1.0*I) goto e70;
      printf("       VARIABLE #%d: %f\n", I, TS[J][1]);
e70:  ;}
    printf("\n       ECONOMIC FUNCTION: %f\n", TS[1][1]);
e100:printf("\n");
}

int main(int argc, char const *argv[])
{
//Part1 - Connection

    int port_no;
    if(argc<2){
        printf("Port no. not provided");
        exit(1);
    }else{
        port_no = atoi(argv[1]);
        printf("Client running on port %d \n", port_no);
    }

    int client_sock;
    struct sockaddr_in server_addr;

    client_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (client_sock < 0){
        error("Error creating error");
    }else{
        printf("Socket created successfully\n");
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port_no);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    int connect_stat = connect(client_sock, (struct sockaddr*) &server_addr, sizeof(server_addr));
    
    if(connect_stat < 0){
        error("Error connecting");
    }else{
        printf("Connected to server \n");
    }

    char message[255];

    int r1 = recv(client_sock, message, sizeof(message), 0);

    if (r1 == -1){
        error("Error receiving message");
    }else{
        printf("Server: %s \n\n", message);
    }


//PART2
    Simplex();
    Results();

    return 0;
}
