#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h> // for close
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include "bitstuffing.c"

#define CMAX  10  //max. number of variables in economic function
#define VMAX  10  //max. number of constraints


int NC, NV, NOPTIMAL,P1,P2,XERR;
double TS[CMAX][VMAX];

void error(char* msg){
    perror(msg);
    exit(1);
}

void Data() {
    double R1,R2;
    char R;
    int I,J;

    printf("\n LINEAR PROGRAMMING\n\n");
    printf(" MAXIMIZE (Y/N) ? "); scanf("%c", &R);
    printf("\n NUMBER OF VARIABLES OF ECONOMIC FUNCTION ? "); scanf("%d", &NV);
    printf("\n NUMBER OF CONSTRAINTS ? "); scanf("%d", &NC);

    if (R == 'Y' || R=='y')
      R1 = 1.0;
    else
      R1 = -1.0;

    printf("\n INPUT COEFFICIENTS OF ECONOMIC FUNCTION:\n");

    for (J = 1; J<=NV; J++) {
      printf("       #%d ? ", J); scanf("%lf", &R2);
      TS[1][J+1] = R2 * R1;
    }

    printf("       Right hand side ? "); scanf("%lf", &R2);

    TS[1][1] = R2 * R1;
    
    for (I = 1; I<=NC; I++) {
      printf("\n CONSTRAINT #%d:\n", I);
      
        for (J = 1; J<=NV; J++) {
            printf("       #%d ? ", J); scanf("%lf", &R2);
            TS[I + 1][J + 1] = -R2;
        }
        printf("       Right hand side ? "); scanf("%lf", &TS[I+1][1]);
    }

    printf("\n\n RESULTS:\n\n");

    for(J=1; J<=NV; J++)  TS[0][J+1] = J;
    for(I=NV+1; I<=NV+NC; I++)  TS[I-NV+1][0] = I;

}

int main(int argc, char const *argv[])
{
    //arg[1] is port no.
    int port_no;

    if (argc < 2){
        printf("No Port number provided\n");
        exit(1);
    }else{
        port_no = atoi(argv[1]);
        printf("Starting server on port %d \n", port_no);
    }

//PART 1  
    int server_sock, client_sock, bind_stat;
    struct sockaddr_in server_addr;

    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port_no);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    bind_stat = bind(server_sock, (struct sockaddr*) &server_addr, sizeof(server_addr));
    if (bind_stat < 0){
        error("Error in binding");
    }else{
        printf("Binding successful\n");
    }

    listen(server_sock, 3);
    printf("Listening for incoming connections\n");

    client_sock = accept(server_sock, NULL, NULL);
    if (client_sock < 0){
        error("Error accepting");
    }else{
        printf("Accepted\n");
    }

    char message[255] = "Hello Client, this is your server!";
    send(client_sock, message, sizeof(message), 0);

    //PART 2
    Data();
    


    return 0;
}
